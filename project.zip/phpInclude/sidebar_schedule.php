<div class="sidebarnav"><!-- // SIDE BAR NAV // -->
                	<span class="dashbar clearfix">
                    	You're about to book 
							<h4>Rutger Teunissen</h4>
						as your expert.
                        <a href="javascript:void(0);" class="togglebtn2 visible-xs" data-toggle="tooltip" title="Click me">
                        	<i class="fa fa-circle"></i><i class="fa fa-circle"></i><i class="fa fa-circle"></i>
                        </a>
                    </span>
                    <div class="toggle_db"><!-- FOR TOGGLED DASHBOARD -->
                        <div class="accountimgblk">
                            <span class="imgcont"><img src="images/users/default.jpg" alt="user" class="responsiveimg" /></span>
                            <span class="uploadimgotr">
                                <input type="file" />
                                <span>
								<a href="#">Back to expert profile</a>
								</span>
                            </span>
                        </div>
                      
                      					
                    </div><!-- FOR TOGGLED DASHBOARD -->
                </div><!-- // SIDE BAR NAV // -->