    <section id="step3" style="display:none;"><!-- // STEP 3 // -->
                        
                        <h2 class="accountheading">Confirm</h2>
                        
                        <div class="schedulemain">
                            
                            <div class="confirmdetail">
                            	<a href="javascript:void(0);" id="edit_step2" class="editlink pull-right"><i class="fa fa-edit"></i> &nbsp;Edit</a>
                            	<h4>Details</h4>
                                <ul>
                                	<li>
                                    	<label>Title</label>
                                        <p id="display_title">--</p>
                                    </li>
                                    <li>
                                    	<label>Description and goals</label>
                                        <p  id="display_description">--</p>
                                    </li>
                                    <li>
                                    	<label>Specific questions</label>
                                        <p id="display_question">--</p>
                                    </li>
                                </ul>
                            </div>
                            
                            <div class="confirmdetail">
                            	<a href="javascript:void(0);" id="edit_step1" class="editlink pull-right"><i class="fa fa-edit"></i> &nbsp;Edit</a>
                            	<h4>Suggested Time</h4>
                                <ul class="timelist" id="display_datetime">
								
                                </ul>
                            </div>
                            
                            <div class="confirmdetail">
                            	<h4>Payment Method</h4>
                                <p>experts will provide you with a quote for a session. If you select a paid session, you will need to provide your <a href="<?php echo $root;?>finance_detail.php" target="_blank">creditcard details</a> before accepting the proposal.</p>
                            </div>
                            
                            <div class="row">
                                <div class="col-xs-12">
                                    <a href="javascript:void(0);" id="book_schedule" class="btn1 proceedbtn">Submit Request <i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </section><!-- // STEP 3 // -->