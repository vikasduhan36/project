<?php 
require_once('phpInclude/header.php');
	
?>

<section class="midsection aboutsection"><!-- // MID MAIN SECTION // -->
	<div class="container">
    	<div class="row">
       		<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
            	<h2>About EyeAsk</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et eros vel turpis tempor sollicitudin vel id massa. Aenean posuere ligula arcu, id tincidunt mauris malesuada id. Proin eu nulla et sem consectetur commodo. </p>
                <div class="abtblk">
                	<h4>Our belief</h4>
                    <p>Phasellus bibendum rhoncus sodales. Fusce scelerisque felis non risus porttitor, at lobortis velit pulvinar. Phasellus blandit sapien nulla, sed aliquam turpis aliquam efficitur. Maecenas euismod arcu quis ligula posuere, et dignissim risus tincidunt. Etiam malesuada posuere euismod. Nunc euismod ex id quam iaculis, a malesuada arcu rhoncus.</p>
                </div>
                <div class="abtblk">
                	<h4>Our mission</h4>
                    <p>Phasellus bibendum rhoncus sodales. Fusce scelerisque felis non risus porttitor, at lobortis velit pulvinar. Phasellus blandit sapien nulla, sed aliquam turpis aliquam efficitur. Maecenas euismod arcu quis ligula posuere, et dignissim risus tincidunt. Etiam malesuada posuere euismod. Nunc euismod ex id quam iaculis, a malesuada arcu rhoncus.</p>
                </div>
                <div class="abtblk">
                	<h4>Our solution</h4>
                    <p>Phasellus bibendum rhoncus sodales. Fusce scelerisque felis non risus porttitor, at lobortis velit pulvinar. Phasellus blandit sapien nulla, sed aliquam turpis aliquam efficitur. Maecenas euismod arcu quis ligula posuere, et dignissim risus tincidunt. Etiam malesuada posuere euismod. Nunc euismod ex id quam iaculis, a malesuada arcu rhoncus.</p>
                </div>
            </div>
        </div>
    </div>
</section><!-- // MID MAIN SECTION // -->


<?php
require_once('phpInclude/footer.php');
?>